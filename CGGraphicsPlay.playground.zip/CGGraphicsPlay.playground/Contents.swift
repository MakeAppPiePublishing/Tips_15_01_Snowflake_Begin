// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 15 (Q3 2021) video 01
//  by Steven Lipton (C)2021, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Make a Koch snowflake
//  For more code, go to http://bit.ly/AppPieGithub

import UIKit
//The extension for turtle graphics.
extension CGContext{
    func addLine(dx:CGFloat,dy:CGFloat){
        var point = self.currentPointOfPath
        point.x += dx
        point.y += dy
        self.addLine(to:point)
    }
    
    func addLine(distance:CGFloat,heading:CGFloat){
        var point = self.currentPointOfPath
        point.x += distance * cos(heading)
        point.y += distance * sin(heading)
        self.addLine(to:point)
    }
    
    func addLine(distance:CGFloat,degrees:CGFloat){
        let heading = degrees * (CGFloat.pi / 180)
        self.addLine(distance: distance, heading: heading)
    }
}

class ViewController:UIViewController{
    var imageView1 = UIImageView()
    var imageView2 = UIImageView()
    
    func snowFlakeSide(context:CGContext, distance:CGFloat, degrees:CGFloat, level:Int){
        
    }
    
    // Life cycle stuff to set up view.
    override func viewDidLoad(){
        super.viewDidLoad()
        imageView1.frame = view.bounds
        imageView1.backgroundColor = .blue
        view.addSubview(imageView1)
        imageView2.frame = imageView1.bounds.insetBy(dx: 20, dy: 20)
        imageView2.backgroundColor = .white
        view.addSubview(imageView2)
        drawStuff()
    }
    
    override func loadView(){
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
        view.backgroundColor = .systemBackground
        self.view = view
    }
    
    
    //do the drawing here.
    func drawStuff(){
        let bounds = imageView2.bounds
        let renderer = UIGraphicsImageRenderer(size: bounds.size)
        let image = renderer.image { rendered in
            let context = rendered.cgContext
            context.move(to: CGPoint(x:305, y:bounds.midY))
             
            
            context.setStrokeColor(UIColor.black.cgColor)
            context.setLineWidth(3)
            context.strokePath()
        }
        imageView2.image = image
    }
    
    
}

import PlaygroundSupport
let vc = ViewController()
PlaygroundPage.current.setLiveView(vc)
